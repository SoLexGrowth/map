import 'package:flutter/material.dart';

const String google_api_key = "AIzaSyAd4rEAQqf58fCJGABqW99teDP9BcuyN08";
const Color primaryColor = Color(0xFF7B61FF);
const double defaultPadding = 16.0;
